module("ajax", { teardown: moduleTeardown });

// Safari 3 randomly crashes when running these tests,
// but only in the full suite - you can run just the Ajax
// tests and they'll pass
//if ( !jQuery.browser.safari ) {

if ( !isLocal ) {

test("jQuery.ajax() - success callbacks", function() {
	expect( 8 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	jQuery('#foo').ajaxStart(function(){
		ok( true, "ajaxStart" );
	}).ajaxStop(function(){
		ok( true, "ajaxStop" );
		start();
	}).ajaxSend(function(){
		ok( true, "ajaxSend" );
	}).ajaxComplete(function(){
		ok( true, "ajaxComplete" );
	}).ajaxError(function(){
		ok( false, "ajaxError" );
	}).ajaxSuccess(function(){
		ok( true, "ajaxSuccess" );
	});

	jQuery.ajax({
		url: url("data/name.html"),
		beforeSend: function(){ ok(true, "beforeSend"); },
		success: function(){ ok(true, "success"); },
		error: function(){ ok(false, "error"); },
		complete: function(){ ok(true, "complete"); }
	});
});

test("jQuery.ajax() - success callbacks - (url, options) syntax", function() {
	expect( 8 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	setTimeout(function(){
		jQuery('#foo').ajaxStart(function(){
			ok( true, "ajaxStart" );
		}).ajaxStop(function(){
			ok( true, "ajaxStop" );
			start();
		}).ajaxSend(function(){
			ok( true, "ajaxSend" );
		}).ajaxComplete(function(){
			ok( true, "ajaxComplete" );
		}).ajaxError(function(){
			ok( false, "ajaxError" );
		}).ajaxSuccess(function(){
			ok( true, "ajaxSuccess" );
		});

		jQuery.ajax( url("data/name.html") , {
			beforeSend: function(){ ok(true, "beforeSend"); },
			success: function(){ ok(true, "success"); },
			error: function(){ ok(false, "error"); },
			complete: function(){ ok(true, "complete"); }
		});
	}, 13);
});

test("jQuery.ajax() - success callbacks (late binding)", function() {
	expect( 8 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	setTimeout(function(){
		jQuery('#foo').ajaxStart(function(){
			ok( true, "ajaxStart" );
		}).ajaxStop(function(){
			ok( true, "ajaxStop" );
			start();
		}).ajaxSend(function(){
			ok( true, "ajaxSend" );
		}).ajaxComplete(function(){
			ok( true, "ajaxComplete" );
		}).ajaxError(function(){
			ok( false, "ajaxError" );
		}).ajaxSuccess(function(){
			ok( true, "ajaxSuccess" );
		});

		jQuery.ajax({
			url: url("data/name.html"),
			beforeSend: function(){ ok(true, "beforeSend"); }
		})
			.complete(function(){ ok(true, "complete"); })
			.success(function(){ ok(true, "success"); })
			.error(function(){ ok(false, "error"); });
	}, 13);
});

test("jQuery.ajax() - success callbacks (oncomplete binding)", function() {
	expect( 8 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	setTimeout(function(){
		jQuery('#foo').ajaxStart(function(){
			ok( true, "ajaxStart" );
		}).ajaxStop(function(){
			ok( true, "ajaxStop" );
		}).ajaxSend(function(){
			ok( true, "ajaxSend" );
		}).ajaxComplete(function(){
			ok( true, "ajaxComplete" );
		}).ajaxError(function(){
			ok( false, "ajaxError" );
		}).ajaxSuccess(function(){
			ok( true, "ajaxSuccess" );
		});

		jQuery.ajax({
			url: url("data/name.html"),
			beforeSend: function(){ ok(true, "beforeSend"); },
			complete: function(xhr) {
				xhr
				.complete(function(){ ok(true, "complete"); })
				.success(function(){ ok(true, "success"); })
				.error(function(){ ok(false, "error"); })
				.complete(function(){ start(); });
			}
		});
	}, 13);
});

test("jQuery.ajax() - success callbacks (very late binding)", function() {
	expect( 8 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	setTimeout(function(){
		jQuery('#foo').ajaxStart(function(){
			ok( true, "ajaxStart" );
		}).ajaxStop(function(){
			ok( true, "ajaxStop" );
		}).ajaxSend(function(){
			ok( true, "ajaxSend" );
		}).ajaxComplete(function(){
			ok( true, "ajaxComplete" );
		}).ajaxError(function(){
			ok( false, "ajaxError" );
		}).ajaxSuccess(function(){
			ok( true, "ajaxSuccess" );
		});

		jQuery.ajax({
			url: url("data/name.html"),
			beforeSend: function(){ ok(true, "beforeSend"); },
			complete: function(xhr) {
				setTimeout (function() {
					xhr
					.complete(function(){ ok(true, "complete"); })
					.success(function(){ ok(true, "success"); })
					.error(function(){ ok(false, "error"); })
					.complete(function(){ start(); });
				},100);
			}
		});
	}, 13);
});

test("jQuery.ajax() - success callbacks (order)", function() {
	expect( 1 );

	jQuery.ajaxSetup({ timeout: 0 });

	stop();

	var testString = "";

	setTimeout(function(){
		jQuery.ajax({
			url: url("data/name.html"),
			success: function( _1 , _2 , xhr ) {
				xhr.success(function() {
					xhr.success(function() {
						testString += "E";
					});
					testString += "D";
				});
				testString += "A";
			},
			complete: function() {
				strictEqual(testString, "ABCDE", "Proper order");
				start();
			}
		}).success(function() {
			testString += "B";
		}).success(function() {
			testString += "C";
		});
	}, 13);
});

test("jQuery.ajax() - error callbacks", function() {
	expect( 8 );
	stop();

	jQuery('#foo').ajaxStart(function(){
		ok( true, "ajaxStart" );
	}).ajaxStop(function(){
		ok( true, "ajaxStop" );
		start();
	}).ajaxSend(function(){
		ok( true, "ajaxSend" );
	}).ajaxComplete(function(){
		ok( true, "ajaxComplete" );
	}).ajaxError(function(){
		ok( true, "ajaxError" );
	}).ajaxSuccess(function(){
		ok( false, "ajaxSuccess" );
	});

	jQuery.ajaxSetup({ timeout: 500 });

	jQuery.ajax({
		url: url("data/name.php?wait=5"),
		beforeSend: function(){ ok(true, "beforeSend"); },
		success: function(){ ok(false, "success"); },
		error: function(){ ok(true, "error"); },
		complete: function(){ ok(true, "complete"); }
	});
});

test( "jQuery.ajax - multiple method signatures introduced in 1.5 ( #8107)", function() {

	expect( 4 );

	stop();

	jQuery.when(
		jQuery.ajax().success(function() { ok( true, 'With no arguments' ); }),
		jQuery.ajax('data/name.html').success(function() { ok( true, 'With only string URL argument' ); }),
		jQuery.ajax('data/name.html', {} ).success(function() { ok( true, 'With string URL param and map' ); }),
		jQuery.ajax({ url: 'data/name.html'} ).success(function() { ok( true, 'With only map' ); })
	).then( start, start );

});

test("jQuery.ajax() - textStatus and errorThrown values", function() {

	var nb = 2;

	expect( 2 * nb );
	stop();

	function startN() {
		if ( !( --nb ) ) {
			start();
		}
	}

	/*
	Safari 3.x returns "OK" instead of "Not Found"
	Safari 4.x doesn't have this issue so the test should be re-instated once
	we drop support for 3.x

	jQuery.ajax({
		url: url("data/nonExistingURL"),
		error: function( _ , textStatus , errorThrown ){
			strictEqual( textStatus, "error", "textStatus is 'error' for 404" );
			strictEqual( errorThrown, "Not Found", "errorThrown is 'Not Found' for 404");
			startN();
		}
	});
	*/

	jQuery.ajax({
		url: url("data/name.php?wait=5"),
		error: function( _ , textStatus , errorThrown ){
			strictEqual( textStatus, "abort", "textStatus is 'abort' for abort" );
			strictEqual( errorThrown, "abort", "errorThrown is 'abort' for abort");
			startN();
		}
	}).abort();

	jQuery.ajax({
		url: url("data/name.php?wait=5"),
		error: function( _ , textStatus , errorThrown ){
			strictEqual( textStatus, "mystatus", "textStatus is 'mystatus' for abort('mystatus')" );
			strictEqual( errorThrown, "mystatus", "errorThrown is 'mystatus' for abort('mystatus')");
			startN();
		}
	}).abort( "mystatus" );
});

test("jQuery.ajax() - responseText on error", function() {

	expect( 1 );

	stop();

	jQuery.ajax({
		url: url("data/errorWithText.php"),
		error: function(xhr) {
			strictEqual( xhr.responseText , "plain text message" , "Test jqXHR.responseText is filled for HTTP errors" );
		},
		complete: function() {
			start();
		}
	});
});

test(".ajax() - retry with jQuery.ajax( this )", function() {

	expect( 1 );

	stop();

	var firstTime = 1;

	jQuery.ajax({
		url: url("data/errorWithText.php"),
		error: function() {
			if ( firstTime ) {
				firstTime = 0;
				jQuery.ajax( this );
			} else {
				ok( true , "Test retrying with jQuery.ajax(this) works" );
				start();
			}
		}
	});

});

test(".ajax() - headers" , function() {

	expect( 4 );

	stop();

	jQuery('#foo').ajaxSend(function( evt, xhr ) {
		xhr.setRequestHeader( "ajax-send", "test" );
	});

	var requestHeaders = {
			siMPle: "value",
			"SometHing-elsE": "other value",
			OthEr: "something else"
		},
		list = [],
		i;

	for( i in requestHeaders ) {
		list.push( i );
	}
	list.push( "ajax-send" );

	jQuery.ajax(url("data/headers.php?keys="+list.join( "_" ) ), {

		headers: requestHeaders,
		success: function( data , _ , xhr ) {
			var tmp = [];
			for ( i in requestHeaders ) {
				tmp.push( i , ": " , requestHeaders[ i ] , "\n" );
			}
			tmp.push(  "ajax-send: test\n" );
			tmp = tmp.join( "" );

			strictEqual( data , tmp , "Headers were sent" );
			strictEqual( xhr.getResponseHeader( "Sample-Header" ) , "Hello World" , "Sample header received" );
			if ( jQuery.browser.mozilla ) {
				ok( true, "Firefox doesn't support empty headers" );
			} else {
				strictEqual( xhr.getResponseHeader( "Empty-Header" ) , "" , "Empty header received" );
			}
			strictEqual( xhr.getResponseHeader( "Sample-Header2" ) , "Hello World 2" , "Second sample header received" );
		},
		error: function(){ ok(false, "error"); }

	}).then( start, start );

});

test(".ajax() - Accept header" , function() {

	expect( 1 );

	stop();

	jQuery.ajax(url("data/headers.php?keys=accept"), {
		headers: {
			Accept: "very wrong accept value"
		},
		beforeSend: function( xhr ) {
			xhr.setRequestHeader( "Accept", "*/*" );
		},
		success: function( data ) {
			strictEqual( data , "accept: */*\n" , "Test Accept header is set to last value provided" );
			start();
		},
		error: function(){ ok(false, "error"); }
	});

});

test(".ajax() - contentType" , function() {

	expect( 2 );

	stop();

	var count = 2;

	function restart() {
		if ( ! --count ) {
			start();
		}
	}

	jQuery.ajax(url("data/headers.php?keys=content-type" ), {
		contentType: "test",
		success: function( data ) {
			strictEqual( data , "content-type: test\n" , "Test content-type is sent when options.contentType is set" );
		},
		complete: function() {
			restart();
		}
	});

	jQuery.ajax(url("data/headers.php?keys=content-type" ), {
		contentType: false,
		success: function( data ) {
			strictEqual( data , "content-type: \n" , "Test content-type is not sent when options.contentType===false" );
		},
		complete: function() {
			restart();
		}
	});

});

test(".ajax() - protocol-less urls", function() {
	expect(1);

	jQuery.ajax({
		url: "//somedomain.com",
		beforeSend: function( xhr, settings ) {
			equals(settings.url, location.protocol + "//somedomain.com", "Make sure that the protocol is added.");
			return false;
		}
	});
});

test(".ajax() - hash", function() {
	expect(3);

	jQuery.ajax({
		url: "data/name.html#foo",
		beforeSend: function( xhr, settings ) {
			equals(settings.url, "data/name.html", "Make sure that the URL is trimmed.");
			return false;
		}
	});

	jQuery.ajax({
		url: "data/name.html?abc#foo",
		beforeSend: function( xhr, settings ) {
		equals(settings.url, "data/name.html?abc", "Make sure that the URL is trimmed.");
			return false;
		}
	});

	jQuery.ajax({
		url: "data/name.html?abc#foo",
		data: { "test": 123 },
		beforeSend: function( xhr, settings ) {
			equals(settings.url, "data/name.html?abc&test=123", "Make sure that the URL is trimmed.");
			return false;
		}
	});
});

test("jQuery ajax - cross-domain detection", function() {

	expect( 4 );

	var loc = document.location,
		otherPort = loc.port === 666 ? 667 : 666,
		otherProtocol = loc.protocol === "http:" ? "https:" : "http:";

	jQuery.ajax({
		dataType: "jsonp",
		url: otherProtocol + "//" + loc.host,
		beforeSend: function( _ , s ) {
			ok( s.crossDomain , "Test different protocols are detected as cross-domain" );
			return false;
		}
	});

	jQuery.ajax({
		dataType: "jsonp",
		url: loc.protocol + '//somewebsitethatdoesnotexist-656329477541.com:' + ( loc.port || 80 ),
		beforeSend: function( _ , s ) {
			ok( s.crossDomain , "Test different hostnames are detected as cross-domain" );
			return false;
		}
	});

	jQuery.ajax({
		dataType: "jsonp",
		url: loc.protocol + "//" + loc.hostname + ":" + otherPort,
		beforeSend: function( _ , s ) {
			ok( s.crossDomain , "Test different ports are detected as cross-domain" );
			return false;
		}
	});

	jQuery.ajax({
		dataType: "jsonp",
		url: loc.protocol + "//" + loc.host,
		crossDomain: true,
		beforeSend: function( _ , s ) {
			ok( s.crossDomain , "Test forced crossDomain is detected as cross-domain" );
			return false;
		}
	});

});

test(".load() - 404 error callbacks", function() {
	expect( 6 );
	stop();

	jQuery('#foo').ajaxStart(function(){
		ok( true, "ajaxStart" );
	}).ajaxStop(function(){
		ok( true, "ajaxStop" );
		start();
	}).ajaxSend(function(){
		ok( true, "ajaxSend" );
	}).ajaxComplete(function(){
		ok( true, "ajaxComplete" );
	}).ajaxError(function(){
		ok( true, "ajaxError" );
	}).ajaxSuccess(function(){
		ok( false, "ajaxSuccess" );
	});

	jQuery("<div/>").load("data/404.html", function(){
		ok(true, "complete");
	});
});

test("jQuery.ajax() - abort", function() {
	expect( 8 );
	stop();

	jQuery('#foo').ajaxStart(function(){
		ok( true, "ajaxStart" );
	}).ajaxStop(function(){
		ok( true, "ajaxStop" );
		start();
	}).ajaxSend(function(){
		ok( true, "ajaxSend" );
	}).ajaxComplete(function(){
		ok( true, "ajaxComplete" );
	});

	var xhr = jQuery.ajax({
		url: url("data/name.php?wait=5"),
		beforeSend: function(){ ok(true, "beforeSend"); },
		complete: function(){ ok(true, "complete"); }
	});

	equals( xhr.readyState, 1, "XHR readyState indicates successful dispatch" );

	xhr.abort();
	equals( xhr.readyState, 0, "XHR readyState indicates successful abortion" );
});

test("Ajax events with context", function() {
	expect(14);

	stop();
	var context = document.createElement("div");

	function event(e){
		equals( this, context, e.type );
	}

	function callback(msg){
		return function(){
			equals( this, context, "context is preserved on callback " + msg );
		};
	}

	function nocallback(msg){
		return function(){
			equals( typeof this.url, "string", "context is settings on callback " + msg );
		};
	}

	jQuery('#foo').add(context)
			.ajaxSend(event)
			.ajaxComplete(event)
			.ajaxError(event)
			.ajaxSuccess(event);

	jQuery.ajax({
		url: url("data/name.html"),
		beforeSend: callback("beforeSend"),
		success: callback("success"),
		error: callback("error"),
		complete:function(){
			callback("complete").call(this);

			jQuery.ajax({
				url: url("data/404.html"),
				context: context,
				beforeSend: callback("beforeSend"),
				error: callback("error"),
				complete: function(){
					callback("complete").call(this);

					jQuery('#foo').add(context).unbind();

					jQuery.ajax({
						url: url("data/404.html"),
						beforeSend: nocallback("beforeSend"),
						error: nocallback("error"),
						complete: function(){
							nocallback("complete").call(this);
							start();
						}
					});
				}
			});
		},
		context:context
	});
});

test("jQuery.ajax context modification", function() {
	expect(1);

	stop();

	var obj = {};

	jQuery.ajax({
		url: url("data/name.html"),
		context: obj,
		beforeSend: function(){
			this.test = "foo";
		},
		complete: function() {
			start();
		}
	});

	equals( obj.test, "foo", "Make sure the original object is maintained." );
});

test("jQuery.ajax context modification through ajaxSetup", function() {
	expect(4);

	stop();

	var obj = {};

	jQuery.ajaxSetup({
		context: obj
	});

	strictEqual( jQuery.ajaxSettings.context, obj, "Make sure the context is properly set in ajaxSettings." );

	jQuery.ajax({
		url: url("data/name.html"),
		complete: function() {
			strictEqual( this, obj, "Make sure the original object is maintained." );
			jQuery.ajax({
				url: url("data/name.html"),
				context: {},
				complete: function() {
					ok( this !== obj, "Make sure overidding context is possible." );
					jQuery.ajaxSetup({
						context: false
					});
					jQuery.ajax({
						url: url("data/name.html"),
						beforeSend: function(){
							this.test = "foo2";
						},
						complete: function() {
							ok( this !== obj, "Make sure unsetting context is possible." );
							start();
						}
					});
				}
			});
		}
	});
});

test("jQuery.ajax() - disabled globals", function() {
	expect( 3 );
	stop();

	jQuery('#foo').ajaxStart(function(){
		ok( false, "ajaxStart" );
	}).ajaxStop(function(){
		ok( false, "ajaxStop" );
	}).ajaxSend(function(){
		ok( false, "ajaxSend" );
	}).ajaxComplete(function(){
		ok( false, "ajaxComplete" );
	}).ajaxError(function(){
		ok( false, "ajaxError" );
	}).ajaxSuccess(function(){
		ok( false, "ajaxSuccess" );
	});

	jQuery.ajax({
		global: false,
		url: url("data/name.html"),
		beforeSend: function(){ ok(true, "beforeSend"); },
		success: function(){ ok(true, "success"); },
		error: function(){ ok(false, "error"); },
		complete: function(){
		  ok(true, "complete");
		  setTimeout(function(){ start(); }, 13);
		}
	});
});

test("jQuery.ajax - xml: non-namespace elements inside namespaced elements", function() {
	expect(3);
	stop();
	jQuery.ajax({
	  url: url("data/with_fries.xml"),
	  dataType: "xml",
	  success: function(resp) {
		equals( jQuery("properties", resp).length, 1, 'properties in responseXML' );
		equals( jQuery("jsconf", resp).length, 1, 'jsconf in responseXML' );
		equals( jQuery("thing", resp).length, 2, 'things in responseXML' );
		start();
	  }
	});
});

test("jQuery.ajax - xml: non-namespace elements inside namespaced elements (over JSONP)", function() {
	expect(3);
	stop();
	jQuery.ajax({
	  url: url("data/with_fries_over_jsonp.php"),
	  dataType: "jsonp xml",
	  success: function(resp) {
		equals( jQuery("properties", resp).length, 1, 'properties in responseXML' );
		equals( jQuery("jsconf", resp).length, 1, 'jsconf in responseXML' );
		equals( jQuery("thing", resp).length, 2, 'things in responseXML' );
		start();
	  },
	  error: function(_1,_2,error) {
		ok( false, error );
		start();
	  }
	});
});

test("jQuery.ajax - HEAD requests", function() {
	expect(2);

	stop();
	jQuery.ajax({
		url: url("data/name.html"),
		type: "HEAD",
		success: function(data, status, xhr){
			var h = xhr.getAllResponseHeaders();
			ok( /Date/i.test(h), 'No Date in HEAD response' );

			jQuery.ajax({
				url: url("data/name.html"),
				data: { whip_it: "good" },
				type: "HEAD",
				success: function(data, status, xhr){
					var h = xhr.getAllResponseHeaders();
					ok( /Date/i.test(h), 'No Date in HEAD response with data' );
					start();
				}
			});
		}
	});

});

test("jQuery.ajax - beforeSend", function() {
	expect(1);
	stop();

	var check = false;

	jQuery.ajaxSetup({ timeout: 0 });

	jQuery.ajax({
		url: url("data/name.html"),
		beforeSend: function(xml) {
			check = true;
		},
		success: function(data) {
			ok( check, "check beforeSend was executed" );
			start();
		}
	});
});

test("jQuery.ajax - beforeSend, cancel request (#2688)", function() {
	expect(2);
	var request = jQuery.ajax({
		url: url("data/name.html"),
		beforeSend: function() {
			ok( true, "beforeSend got called, canceling" );
			return false;
		},
		success: function() {
			ok( false, "request didn't get canceled" );
		},
		complete: function() {
			ok( false, "request didn't get canceled" );
		},
		error: function() {
			ok( false, "request didn't get canceled" );
		}
	});
	ok( request === false, "canceled request must return false instead of XMLHttpRequest instance" );
});

test("jQuery.ajax - beforeSend, cancel request manually", function() {
	expect(2);
	var request = jQuery.ajax({
		url: url("data/name.html"),
		beforeSend: function(xhr) {
			ok( true, "beforeSend got called, canceling" );
			xhr.abort();
		},
		success: function() {
			ok( false, "request didn't get canceled" );
		},
		complete: function() {
			ok( false, "request didn't get canceled" );
		},
		error: function() {
			ok( false, "request didn't get canceled" );
		}
	});
	ok( request === false, "canceled request must return false instead of XMLHttpRequest instance" );
});

window.foobar = null;
window.testFoo = undefined;

test("jQuery.ajax - dataType html", function() {
	expect(5);
	stop();

	var verifyEvaluation = function() {
		equals( testFoo, "foo", 'Check if script was evaluated for datatype html' );
		equals( foobar, "bar", 'Check if script src was evaluated for datatype html' );

		start();
	};

	jQuery.ajax({
	  dataType: "html",
	  url: url("data/test.html"),
	  success: function(data) {
		jQuery("#ap").html(data);
		ok( data.match(/^html text/), 'Check content for datatype html' );
		setTimeout(verifyEvaluation, 600);
	  }
	});
});

test("serialize()", function() {
	expect(5);

	// Add html5 elements only for serialize because selector can't yet find them on non-html5 browsers
	jQuery("#search").after(
		'<input type="email" id="html5email" name="email" value="dave@jquery.com" />'+
		'<input type="number" id="html5number" name="number" value="43" />'
	);

	equals( jQuery('#form').serialize(),
		"action=Test&radio2=on&check=on&hidden=&foo%5Bbar%5D=&name=name&search=search&email=dave%40jquery.com&number=43&select1=&select2=3&select3=1&select3=2&select5=3",
		'Check form serialization as query string');

	equals( jQuery('#form :input').serialize(),
		"action=Test&radio2=on&check=on&hidden=&foo%5Bbar%5D=&name=name&search=search&email=dave%40jquery.com&number=43&select1=&select2=3&select3=1&select3=2&select5=3",
		'Check input serialization as query string');

	equals( jQuery('#testForm').serialize(),
		'T3=%3F%0D%0AZ&H1=x&H2=&PWD=&T1=&T2=YES&My+Name=me&S1=abc&S3=YES&S4=',
		'Check form serialization as query string');

	equals( jQuery('#testForm :input').serialize(),
		'T3=%3F%0D%0AZ&H1=x&H2=&PWD=&T1=&T2=YES&My+Name=me&S1=abc&S3=YES&S4=',
		'Check input serialization as query string');

	equals( jQuery('#form, #testForm').serialize(),
		"action=Test&radio2=on&check=on&hidden=&foo%5Bbar%5D=&name=name&search=search&email=dave%40jquery.com&number=43&select1=&select2=3&select3=1&select3=2&select5=3&T3=%3F%0D%0AZ&H1=x&H2=&PWD=&T1=&T2=YES&My+Name=me&S1=abc&S3=YES&S4=",
		'Multiple form serialization as query string');

  /* Temporarily disabled. Opera 10 has problems with form serialization.
	equals( jQuery('#form, #testForm :input').serialize(),
		"action=Test&radio2=on&check=on&hidden=&foo%5Bbar%5D=&name=name&search=search&email=dave%40jquery.com&number=43&select1=&select2=3&select3=1&select3=2&T3=%3F%0D%0AZ&H1=x&H2=&PWD=&T1=&T2=YES&My+Name=me&S1=abc&S3=YES&S4=",
		'Mixed form/input serialization as query string');
	*/
	jQuery("#html5email, #html5number").remove();
});

test("jQuery.param()", function() {
	expect(24);

	equals( !jQuery.ajaxSettings.traditional, true, "traditional flag, falsy by default" );

	var params = {foo:"bar", baz:42, quux:"All your base are belong to us"};
	equals( jQuery.param(params), "foo=bar&baz=42&quux=All+your+base+are+belong+to+us", "simple" );

	params = {someName: [1, 2, 3], regularThing: "blah" };
	equals( jQuery.param(params), "someName%5B%5D=1&someName%5B%5D=2&someName%5B%5D=3&regularThing=blah", "with array" );

	params = {foo: ['a', 'b', 'c']};
	equals( jQuery.param(params), "foo%5B%5D=a&foo%5B%5D=b&foo%5B%5D=c", "with array of strings" );

	params = {foo: ["baz", 42, "All your base are belong to us"] };
	equals( jQuery.param(params), "foo%5B%5D=baz&foo%5B%5D=42&foo%5B%5D=All+your+base+are+belong+to+us", "more array" );

	params = {foo: { bar: 'baz', beep: 42, quux: 'All your base are belong to us' } };
	equals( jQuery.param(params), "foo%5Bbar%5D=baz&foo%5Bbeep%5D=42&foo%5Bquux%5D=All+your+base+are+belong+to+us", "even more arrays" );

	params = { a:[1,2], b:{ c:3, d:[4,5], e:{ x:[6], y:7, z:[8,9] }, f:true, g:false, h:undefined }, i:[10,11], j:true, k:false, l:[undefined,0], m:"cowboy hat?" };
	equals( decodeURIComponent( jQuery.param(params) ), "a[]=1&a[]=2&b[c]=3&b[d][]=4&b[d][]=5&b[e][x][]=6&b[e][y]=7&b[e][z][]=8&b[e][z][]=9&b[f]=true&b[g]=false&b[h]=undefined&i[]=10&i[]=11&j=true&k=false&l[]=undefined&l[]=0&m=cowboy+hat?", "huge structure" );

	params = { a: [ 0, [ 1, 2 ], [ 3, [ 4, 5 ], [ 6 ] ], { b: [ 7, [ 8, 9 ], [ { c: 10, d: 11 } ], [ [ 12 ] ], [ [ [ 13 ] ] ], { e: { f: { g: [ 14, [ 15 ] ] } } }, 16 ] }, 17 ] };
	equals( decodeURIComponent( jQuery.param(params) ), "a[]=0&a[1][]=1&a[1][]=2&a[2][]=3&a[2][1][]=4&a[2][1][]=5&a[2][2][]=6&a[3][b][]=7&a[3][b][1][]=8&a[3][b][1][]=9&a[3][b][2][0][c]=10&a[3][b][2][0][d]=11&a[3][b][3][0][]=12&a[3][b][4][0][0][]=13&a[3][b][5][e][f][g][]=14&a[3][b][5][e][f][g][1][]=15&a[3][b][]=16&a[]=17", "nested arrays" );

	params = { a:[1,2], b:{ c:3, d:[4,5], e:{ x:[6], y:7, z:[8,9] }, f:true, g:false, h:undefined }, i:[10,11], j:true, k:false, l:[undefined,0], m:"cowboy hat?" };
	equals( jQuery.param(params,true), "a=1&a=2&b=%5Bobject+Object%5D&i=10&i=11&j=true&k=false&l=undefined&l=0&m=cowboy+hat%3F", "huge structure, forced traditional" );

	equals( decodeURIComponent( jQuery.param({ a: [1,2,3], 'b[]': [4,5,6], 'c[d]': [7,8,9], e: { f: [10], g: [11,12], h: 13 } }) ), "a[]=1&a[]=2&a[]=3&b[]=4&b[]=5&b[]=6&c[d][]=7&c[d][]=8&c[d][]=9&e[f][]=10&e[g][]=11&e[g][]=12&e[h]=13", "Make sure params are not double-encoded." );

	// Make sure empty arrays and objects are handled #6481
	equals( jQuery.param({"foo": {"bar": []} }), "foo%5Bbar%5D=", "Empty array param" );
	equals( jQuery.param({"foo": {"bar": [], foo: 1} }), "foo%5Bbar%5D=&foo%5Bfoo%5D=1", "Empty array param" );
	equals( jQuery.param({"foo": {"bar": {}} }), "foo%5Bbar%5D=", "Empty object param" );

	// #7945
	equals( jQuery.param({"jquery": "1.4.2"}), "jquery=1.4.2", "Check that object with a jQuery property get serialized correctly" );

	jQuery.ajaxSetup({ traditional: true });

	var params = {foo:"bar", baz:42, quux:"All your base are belong to us"};
	equals( jQuery.param(params), "foo=bar&baz=42&quux=All+your+base+are+belong+to+us", "simple" );

	params = {someName: [1, 2, 3], regularThing: "blah" };
	equals( jQuery.param(params), "someName=1&someName=2&someName=3&regularThing=blah", "with array" );

	params = {foo: ['a', 'b', 'c']};
	equals( jQuery.param(params), "foo=a&foo=b&foo=c", "with array of strings" );

	params = {"foo[]":["baz", 42, "All your base are belong to us"]};
	equals( jQuery.param(params), "foo%5B%5D=baz&foo%5B%5D=42&foo%5B%5D=All+your+base+are+belong+to+us", "more array" );

	params = {"foo[bar]":"baz", "foo[beep]":42, "foo[quux]":"All your base are belong to us"};
	equals( jQuery.param(params), "foo%5Bbar%5D=baz&foo%5Bbeep%5D=42&foo%5Bquux%5D=All+your+base+are+belong+to+us", "even more arrays" );

	params = { a:[1,2], b:{ c:3, d:[4,5], e:{ x:[6], y:7, z:[8,9] }, f:true, g:false, h:undefined }, i:[10,11], j:true, k:false, l:[undefined,0], m:"cowboy hat?" };
	equals( jQuery.param(params), "a=1&a=2&b=%5Bobject+Object%5D&i=10&i=11&j=true&k=false&l=undefined&l=0&m=cowboy+hat%3F", "huge structure" );

	params = { a: [ 0, [ 1, 2 ], [ 3, [ 4, 5 ], [ 6 ] ], { b: [ 7, [ 8, 9 ], [ { c: 10, d: 11 } ], [ [ 12 ] ], [ [ [ 13 ] ] ], { e: { f: { g: [ 14, [ 15 ] ] } } }, 16 ] }, 17 ] };
	equals( jQuery.param(params), "a=0&a=1%2C2&a=3%2C4%2C5%2C6&a=%5Bobject+Object%5D&a=17", "nested arrays (not possible when jQuery.param.traditional == true)" );

	params = { a:[1,2], b:{ c:3, d:[4,5], e:{ x:[6], y:7, z:[8,9] }, f:true, g:false, h:undefined }, i:[10,11], j:true, k:false, l:[undefined,0], m:"cowboy hat?" };
	equals( decodeURIComponent( jQuery.param(params,false) ), "a[]=1&a[]=2&b[c]=3&b[d][]=4&b[d][]=5&b[e][x][]=6&b[e][y]=7&b[e][z][]=8&b[e][z][]=9&b[f]=true&b[g]=false&b[h]=undefined&i[]=10&i[]=11&j=true&k=false&l[]=undefined&l[]=0&m=cowboy+hat?", "huge structure, forced not traditional" );

	params = { param1: null };
	equals( jQuery.param(params,false), "param1=null", "Make sure that null params aren't traversed." );

	params = {'test': {'length': 3, 'foo': 'bar'} };
	equals( jQuery.param( params, false ), "test%5Blength%5D=3&test%5Bfoo%5D=bar", "Sub-object with a length property" );
});

test("synchronous request", function() {
	expect(1);
	ok( /^{ "data"/.test( jQuery.ajax({url: url("data/json_obj.js"), dataType: "text", async: false}).responseText ), "check returned text" );
});

test("synchronous request with callbacks", function() {
	expect(2);
	var result;
	jQuery.ajax({url: url("data/json_obj.js"), async: false, dataType: "text", success: function(data) { ok(true, "sucess callback executed"); result = data; } });
	ok( /^{ "data"/.test( result ), "check returned text" );
});

test("pass-through request object", function() {
	expect(8);
	stop();

	var target = "data/name.html";
	var successCount = 0;
	var errorCount = 0;
	var errorEx = "";
	var success = function() {
		successCount++;
	};
	jQuery("#foo").ajaxError(function (e, xml, s, ex) {
		errorCount++;
		errorEx += ": " + xml.status;
	});
	jQuery("#foo").one('ajaxStop', function () {
		equals(successCount, 5, "Check all ajax calls successful");
		equals(errorCount, 0, "Check no ajax errors (status" + errorEx + ")");
		jQuery("#foo").unbind('ajaxError');

		start();
	});

	ok( jQuery.get(url(target), success), "get" );
	ok( jQuery.post(url(target), success), "post" );
	ok( jQuery.getScript(url("data/test.js"), success), "script" );
	ok( jQuery.getJSON(url("data/json_obj.js"), success), "json" );
	ok( jQuery.ajax({url: url(target), success: success}), "generic" );
});

test("ajax cache", function () {
	expect(18);

	stop();

	var count = 0, [ 4, 5 ]c.ajax({url: url(targeteS() {
	expe	expecsone('ajaxSt sure that ttpect(3);corE?=(.*?)(&|$)/g;tpect(3oldOnendow.testn requect(3i5 ]c.3i5< 6.3i++tmp = [];
	rname.re. res(ing",bort()unt !rnaok( thisbreakort()}
	})oldOnendorna[1]	ok( reorCount,ieadySt crosquameridding cialiop' 'no-ction'lse ),eto last erro"ta.matcholdOnen!l.stobrroplts (555"ySt crosquabms are not deto l(untiated f erro)ted froplts ("ta.maif(++[ 4, 5 = 6);
		}
	});
});Query.get(url(tarurl(target)js"), su	error:,nction:ponseTeength%5acks",no not deto sQuery.ajax({url: url(target)js"), su	error?pizzase&l[:,nction:ponseTeength%5acks",1 not deto Query.ajax({url: url(target)js"), su	error?_=tobrroplts (555"ySction:ponseTeength%5acks",_= not deto Query.ajax({url: url(target)js"), su	error?pizzase&l[&_=tobrroplts (555"ySction:ponseTeength%5acks",1 not deto  plwit_= op'Query.ajax({url: url(target)js"), su	error?_=tobrroplts (555&tv		},
		ySction:ponseTeength%5acks",1 not deto  plwit_= op', cancetiaQuery.ajax({url: url(target)js"), su	error?earchDavid&_=tobrroplts (555&wrunnrese&l[:,nction:ponseTeength%5acks",2 not deto ss arr04") is _= op'Queryari 3 *
 ly det cara 10 h
 ly her Xse);

t );
	storotocol is  Xsed-inh a jQueryls bmsn throowb
 lywhichre-insted."bxt is pase. Fixes #5439. cache"se,
		gs." );

	jQu() {
	expect(2);

	stop();
	jQ];
			for ({url: u	en(){{], Settings.traditionault;
	jQject: nulrget)js"), xml"),
	  dataT( jQu];
		ajaxSetup({ traditionalp_it: "'b', equal,, beep:BAR'}params tor ({url: u	en(){{], jectult;t.tent-ery.ajx({url: url("tery.ajaxtng",.);
?>Of('} };) > -1 &&xtng",.);
?>Of('qual) > -1 ajax erru	en() is {}ms = {'tor ({url: u	en(){{], jectult;t.tent-ery zb', e']};p };
	'b' .ajx({url: url("tery.ajaxtng",.);
?>Of('p	jQue > -1 &&xtng",.);
?>Of('z };) > -1 &&xtng",.);
?>Of('} };) > -1 &&xtng",.);
?>Of('qual) > -1 ajax erru	en() is { zb', e']};p };
	'b' .ry.ajaxSetup({ traditllback "" )ryari .ajacache"404.hC";
		n() {
	expect(24);

	equa;

	var chec //lse;

	unt404.st thbencelingacks",cialig",foo').ajaxStl(ta'a/404.html",  "Make sure }
	})t("ajax cache"404.h'g",an't yet 'n() {
	expect(24);

	equa;

	var chec //lse;

	unt404.st thbencelingacks",cialig",foo').ajaxStl(ta'a/404.html", cach3ke su cav.use)(){
		ok(true, "cery('#form, #te			st.childrsefunctio 'things in "Vtion,rotocos	eqhrounly for se);
		injoss-dt();
	}).ajaxSend(f("ajax cache"404.hCDE", "PF		ok(tr)gth protraditiol5 bml", funck( j) {
e #2046() {
	expect(1);
	stop();

	var checkxSetup({ traditionalp_itp xml",
	  " ("#foo").one('al(ta"ete(function(){
		ok( fSt sure that ttpeery('#fos.p_itp xm, url: ur "Vtion,rote 4 errorml", funced frl: u ("#foo").unbindl(ta"etxError'te" );
	}).aja("#foo").un{ traditionalp_itp xml"," ("#fo}).ajaxSend(f("oo').ajaxStl(ta'a/404.html", cach3ke su"f("ajax cache"404.hCDE", "PF		ok(tr)g- 
	para:	injossge" , inquaDOM() {
	expect(2);
	var result;ar checkxSetup(axStl(ta'a/404.hame.html"),
		beforeSe {
		successCounta"/.tERRORult ), Setup(axStl(ta'a/e" ,()) script src  datatyped finjoss-d inquaote DOMt();
	  },
	  err(f("ajax cache"404.hCDE", "PF		ok(tr)g-lse;

		ok( ju() {
	expect(2);

	stop(7

	var verifyEvaluation = function() {
		equals( testFoo, "fr", 'Check if script src was evaluated for datatypinput 4 erls( jQuery("thing", re'#ap');
		ok) scqual,,cript src was evae function(s win throow DOMt();
	};

	jQuery.ajxSetup(axStl(ta'a/404.hame.'tml"),
	  succ'Se {
		successCounta"/Setup(axStl(ta'a/
		ok)ml text/), 'Check content for datatypinput 4 er is equals( foobar, "bao').ajaxStart(f
		ok) sctart,,cript src was evae function(s win throow DOMt();estFoo, "foo", 'Check if script was evaluated for datatypinput 4 erls( jQuverifyEvaluation, 600);
	  }
	});
})(f("ajax cache"404.hCDE", "PF		ok(tr)g-lse;

	fileacks",cialia evaluattag() {
	expect(3);
	stop();
	jQuery.ajajxSetup(axStl(ta'a/404.hame.'tml"),
	 2 succ'Se {
		successCounbar, "bao').ajaxStart(f
		ok) sctart,,cript src was evae function(s win throow DOMt();estFoo, "foo", 'Check if script was evaluated for datatypinput 4 erls( j
	  },
	  err(f("ajax cache"404.hCDE", "PF		ok(tr)g-ltml"Filto langs." );

	jQu() {
	expect(2);

	stop();
	var checkxSetup({ traditionalp_itFilto ) {
			ok( false insted" , "Sample ( /^{ "davalunctor ({url:load("data/404.hame.html"),
		beforeSe {
		succet ), "check ssCount data , "contav.
		ok) sd" , "Sample head det cavted fHTTP ererialiilto  er( res();
	  }data , "cont ), "check  sd" , "Sample head det ecuted");;
		},
sliilto  er( res();
	 Setup({ traditionalp_itFilto ) 0 ("#fo}).ajaxSend(f("ajax cache"404.hCDE", "P=17", "PF		ok(tr)() {
	expect(2);

	stop();
	var checkjxSetup(axad("equaa/404.hame.'tml")se ), _
		orror'Se {, "fo3,, bee'ok' g:fa
		successCounvalu$k( jor ({url:l			st.fror')#k( jt();estFoo, "f$k( j.fror')#tart(fe" ,() sc3t,,cript src action" );tent-." ) Xsed );

	jQuet();estFoo, "f$k( j.fror')#qual)fe" ,() scok',,cript src action" );tent-." ) Xsed );

	jQuet();es).ajaxSend(f("ajax cache"404.hCDE", "PCDE", "PF		ok(tr)() {
	expect(2);

	stop();
	var checkjxSetup(axad("equaa/404.hame.'tml")se ), _
		orror'Se ctar&b[dar=ok',,a
		successCounvalu$/name.({url:l			st.fror')#/nat();estFoo, "f$/na.fror')#tart(fe" ,() sc3t,,cript src acparam a );tent-." ) Xsed );

	jQuet();estFoo, "f$/na.fror')#qual)fe" ,() scok',,cript src a	" );tent-." ) Xsed );

	jQuet();es).ajaxSend(f("ajax cache"url(target)CDE", "PF		ok(tr)g-ltml"langs." );

	jQu (#827on() {

	expect( 4
	stop();

	var checkxSetup({ traditiona
hip_it: "h , "wmple nd(f("oo').ajrget), su'tml")echourl(taror'Se ta) {
		jQuery("#apta"/.h , "wmple$ult ), "	stric,,cDstrifromgs." );

	jQu ed fused');
	 Setup({ traditiona
whip_it: w.te
});

});).ajaxSend(f("ajax cache"url(target)CDE", "PHion"PF		ok(tr)g-lse seure s arer cae" ,()l5 brodon() {

	var nb = 

	stop();
	var checkxSetup({get), su'tml")dionboarddata'Se ta) {
		jheck = tr = documentor ( i inSetup(axta	equheck.eaext{
			ok( false, ocumentax-sen({url:l			st.e" ,());
});

});tFoo, "focument[04,5,6la6la',,cript stl(ta ta	e

});tFoo, "focument[14,5,6lu6lu',,cript sse headta	e

});).ajaxSend(f("ajax cache"url(target"data/tCDE", "PF		ok(tr)g-lcks", functio() {
	expect(3);
	stop();
	jQuery.ajax({
	  url("data/test.js"), success), "ata ) {
			str, _,onseTe s( testFoo, "fr", 'Check if script src was evaed for dataty'();
	  }data , "con	str, nseText is filled ,ader2eection",was evafunctionK" insteaote source , "ste,was eva(#8082rictEquaverifyEvalut );

}1});
})(f("ajax cache"url(target"data/tCDE", "PF		ok(tr)g-lno, functio() {
	expect(3);
	stop();

	var checkxSetup({rl("data/test.js"), success), "ata ) {
	){});).ajaxSend(f("ajax ({url: uaext [ader2e etectehat o" ); etecteh;
			ata ) {
		 , "Test forcela6el t( 4 )y.ajax() - disabled glnctio,atus;la6ele {
		successCounb	stop()0( j
	  0, [ 4, 5 ]c.a	ocallback(plwi; },unt )++[ 4, 5 = 18 t( 13);
		}
j
	  } checkjxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lno, functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lno, functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  data? functio=?T,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lg",a functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lg",a functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: fup_it: " functio=?T,
whinction( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,l	stri functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,l	stri functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  data? functio=??T,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lg",a ossibl-freea functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lg",a ossibl-freea functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: fup_it: " functio=??T,
whinction( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,l	stri ossibl-freea functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,l	stri ossibl-freea functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  data/??T,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lREST-likerictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lREST-likerictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  data/???"),  arr
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( this( jQuery.ajaxSettingr" i Query]=2&param, "ncti"check sext" );
})(GET,lREST-likelcks",se ),rictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lREST-likelcks",se ),rictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: furl: l: " functioT,
whinction( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,l	stri	jQu functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,l	stri	jQu functiorictEqual	plwi; ort()}
});

}jxxFoo = url: lRheck se= ta) {
		jQuery("#apstch(/^htm	str, "ncti"check sext" );
})(GET,lcu } m ecuted");ta) {
		rictEqualFoo = url: lRheck se= 
test("jQueal	plwi; ort(}
}jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: furl: lCcuted")		url: lRheck sT,
whinction( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lcu } m ecuted");,
		rictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lcu } m ecuted");,
		rictEqual	plwi; ort()}
});

}jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: furl: lCcuted")		u{
			ok(ToCleanUpT,
whinction( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lcu } m ecuted");,
		squabmsclean
})uprictEqual	( jQuery.ajaxar = nul
			ok(ToCleanUp, 
test("jQat ocuted");ed fro

te})(GET,lcu } m ecuted");,
		squabmsclean
})uprictEqual	plwi; ort()jQuery.aort()j({
				url: url("ddata/nobj.js"),  dataT,
whihip_itp",
		url: loc.prnrn: true,
		bef: true,
		bs: fufurl: lCcuted")		u{
			ok(ToCleanUpT,
whid: function( _ , s ) {
	nseTe s( tesssssy.ajax(seTe;tessssse;
		},
		succes	;
				}
		});
		;
		eon(){
		ok( fal this !== objs callA(status" lncti)(GET,lcu } m ecuted");,
		squabmsclean
})uprictEqual		( jQuery.ajaxar = nul
			ok(ToCleanUp, 
test("jQat ocuted");ed fro

te})input eaajax},
		)(GET,lcu } m ecuted");,
		squabmsclean
})uprictEqual		plwi; ort()j} ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lcu } m ecuted");,
		squabmsclean
})uprictEqual	plwi; ort()}
});

}jxx({
			url: url("d",
				POSTT,
whiata/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(POST,lno, functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,l	stri	jQu functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("d",
				POSTT,
whiata/nobj.js"),  dataT,
whip_it: " functio=?T,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(POST,l	stri functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(POST,l	stri functiorictEqual	plwi; ort()}
});

}jxx({
			url: url("d",
				POSTT,
whiata/nobj.js"),  dataT,
whirl: l: " functioT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(POST,l	stri	jQu functiorictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(POST,l	stri	jQu functiorictEqual	plwi; ort()}
});

}jxx//#7578jxx({
			url: url("data/nobj.js"),  dataT,
whip_itp",
		url: loc.prn: true,
		bef: true,
		bs: fu function(){
							this.tes( this, obj, "Mak.ction,nceled requionn falsbmsest%5Bon ncti"chction(ctEqual	plwi; ort()je;
		},
		succes	}
});

}jxx({
			url: url("data/nobj.js"),  data? functio=XXXT,
whip_itp",
		url: loc.prnrl: l: l: url("durl: lCcuted")		uXXXT,
whi: true,
		bef: true,
		bs: fu function(){
							th ( thistch(/^p_it\s"),  data\? functio=XXX&_=\d+$ult ), "string", s(,
whid:"Trimmed.ed ed."meXsed cks",(GET,lcu } m ecuted");,
		scks",no g", manipula{
		rictEqual	plwi; ort()}s: function( _1 , _2 , Query( thistch(/^htm	str, "ncti"check sext" );
})(GET,lcu } m ecuted");,
		scks",no g", manipula{
		rictEqual	plwi; ort()}s: fution() {
			ok( Query( thistch(celed reA(status" lncti)(GET,lcu } m ecuted");,
		scks",no g", manipula{
		rictEqual	plwi; ort()}
});

}jxst("jQuery.ajax() - disabled glwas ev,lRo

te() {
	expect(2);

	stop();
	jQ];
	long =xar = nuotocol + href.roplts (/[^\/]*$/ reion evar checkjxSetup(rl: url("data/nlong + js"), success)s: fp_itp",
		u	ok( jQ: function(data) {
			ok( c"#apstch(r", 'ChecSas evafueck sext" );
})(GET,lno, functiorictEqual}
	});
});

test("jQuery.ajax - beforeSeed glwas ev,lRo

tescks",POSTT, {
	expect(3);
	stop();
	jjQ];
	long =xar = nuotocol + href.roplts (/[^\/]*$/ reion evar checkjxSetup(rl: url("data/nlong + js"), success)s: f",
				POSTT,
whp_itp",
		u	ok( jQ: function(data) {
			ok( hr){
			c"#apstch(r", 'ChecSas evafueck sext" );
})(POST,lno, functiorictEqualery('#fos{
					 },
		errhecSas evafueck sext" );
})(POST,lno, functiorictEqual}
	});
});

function() {
			ok( k( true, "befoxSuccess" );atus" hr){
			 onentatus;

		){
			 tEqual}
	});
});

test("jQuery.ajax - beforeSeed glwas ev,lRo

tescks",sionme-lion(med() {
	expect(2);

	stop();
	jQ];
	long =xar = nuotocol + href.roplts (/[^\/]*$/ reion 	long =xlong.roplts (/^.*?\/\// re//ion evar checkjxSetup(rl: url("data/nlong + js"), success)s: fp_itp",
		u	ok( jQ: function(data) {
			ok( c"#apstch(r", 'ChecSas evafueck sext" );
})(GET,lno, functiorictEqual}
	});
});

test("jQuery.ajax - beforeSeed glmalseri
})ncti() {
	expect(2);

	stop();
	jQuery.ajajxSetup(rl: url("data/njs"), bad"), ess)s: fp_itp",
		u
	  ": function(){ ok(true, "e, "befoxSuccesspe	expe.ictEqual}
	});
});

function() {
			ok( k( ,;
	},s crailedMsgtrue, "ery('#fo"se ser
		com,;
	},s"Alse seutus" loccurrjQuery.ajaxtch(/^Invali})nctiult ),  crailedMsgt,s"Dcrailed se ser
		co"meXsage);
}vid-dt();
	  al}
	});
});

test("jQuery.ajax - beforeSeed glwas ev" );ocument-",
	() {
	expect(2);

	stop();
	jQuery.ajajxSetup(r.par(}jxx({
			url: url("data/nobj.jswas evdataT,
whip_it: { h				o		u	ok( jQ }
});
,}jxx({
			url: url("data/nobj.jswas evdataT,
whip_it: { h				o		uecmaQ }
});
}jx).tpar( t );

}t );
st("jQuery.ajax - beforeSeed gl
	  " );ocument-",
	() {
	expect(2);

	stop(5;
	jQuery.ajajxSetup(rl: url("data/njs"), "), eataT,
whp_it: { h				o		u
	  ":l
	  :=2&paramss: function(){ ok(true,l
	  "(2);
  alta"/S), eerty" )>= in "ript serty" ");
	  albar, "bao), [0].,
		, 'John',,cript sncti:stl(ta,;,
		' );
	  albar, "bao), [0].age, 21,,cript sncti:stl(ta,;age' );
	  albar, "bao), [1].,
		, 'Peto ',,cript sncti:sse hea,;,
		' );
	  albar, "bao), [1].age, 25,,cript sncti:sse hea,;age' );
	  al}
	});
});

test("jQuery.ajax - beforeSeed gl
	  " );ocument-",
	lobals", fcks",cp;

t () {
	expect(2);

	stop(6;
	jQuery.ajajxSetup(rl: url("data/nson_obj.js"), dataType:hp_it: { h				o		u
	  ":l
	  :=2&paramss: fuocument(){{("durl: 		});
				s: function(){ ok(true,le" , true, "ery('#fo.url, "s" , ,"context  
	ok( j.ed ed."auto-deto m("jQery.ajax];
	k( j.=am( params,seata/jle" , t;;
  alta"/S), eerty" )>= in "ript serty" ");
	  albar, "bao), [0].,
		, 'John',,cript sncti:stl(ta,;,
		' );
	  albar, "bao), [0].age, 21,,cript sncti:stl(ta,;age' );
	  albar, "bao), [1].,
		, 'Peto ',,cript sncti:sse hea,;,
		' );
	  albar, "bao), [1].age, 25,,cript sncti:sse hea,;age' );
	  al}
	});
});

test("jQuery.ajax - befo("data/jCDE", "PHion"PF		ok(tr)g-lncti)&param, {
	expect(5);
	stop();

	var verif	 - befo("data/json_obj.js"), dataTyp {
	  :=2&paramg:fa
		succe
	  (2);
  ta"/S), eerty" )>= in "ript serty" ");
	  bar, "bao), [0].,
		, 'John',,cript sncti:stl(ta,;,
		' );
	  bar, "bao), [0].age, 21,,cript sncti:stl(ta,;age' );
	  bar, "bao), [1].,
		, 'Peto ',,cript sncti:sse hea,;,
		' );
	  bar, "bao), [1].age, 25,,cript sncti:sse hea,;age' );
	  ).ajaxSend(f("ajax cache"url(targetata/jCDE", "PF		ok(tr)g-lncti)nction() {
	expect(8);
	stop());
	var checkxSetup({getata/json_obj.js"), dataTyp a
		succe
	  (2);
  unt k( j.&&/S), eQuery("#ap  bar, "bao), eQuer.la, "P'en',,cript sncti:sla, '();
	   bar, "bao), eQuer.lthings i5,,cript sncti:s 'foo': );
	  }
	  ).ajaxSend(f("ajax cache"url(targetata/g-lUsam aNcolve)ncti() {
	expect(2);

	stop();
	jQct(3old =xar = nunctiendata/g=("#apms,se){ ok(true,ont "e, "befojs callVtion,am aotocose seumethoted" )runurn false;
		},		successry.ajaxar checkxSetup({getata/json_obj.js"), dataTyp a
		succe
	  (2);
	ar = nunctig=(oldccesbar, "bao), ,ojs callVtion,am ae;
		},/>'
	t();
	}).ajaxSend(f("ajax cache"url(targetata/jCDE", "PF		ok(tr)g-lncti)nctiongth probsolutesg", to otocl;ocument() {
	expect(2);

	stop();
	jQ];
	long =xar = nuotocol + href.roplts (/[^\/]*$/ reion evar checkxSetup({getata/json_long + js"), "), dataTyp a
		succe
	  (2);
  bar, "bao), eQuer.la, "P'en',,cript sncti:sla, '();
	  bar, "bao), eQuer.lthings i5,,cript sncti:s 'foo': );
	  ).ajaxSend(f("ajax cache"url(tark( jo-ltml"() 3) {
	expect(2);
uery.ajajxSetup(r.par(}xx({
			urget)nson_.html";
	varataT Se {,mespa"5-that 'foo': 3 g:fa
		succeure strue, "({url:l 'mao':,ure st uaext 
							th ( thisbar, "bao').aja 'oclcula{
		:,uj, "M)fe" ,() sc5-t',,cript stco"tart();
	 isbar, "bao').aja 'fueck :,uj, "M)fe" ,() sc3',,cript stco"tart();
	 i;

});

,}jxx({
			url: url("data/n, su'tml")echoDuer.ror'Sel("d",
				POSTT,
whip_it: {
	 isength': 3
whid:, 'foo': '7,
whid:	'} };
	equal
whid}rt()}s: function( _1 , _2 , "	stric is.tes( this, obj, ok( hr'th%5D=3&test%5Bfo7%5D=bar", "Sub-objt,,cript src acpith a length property" );e ),-." correctly" );

	jQue' ort()}
});
jx).tpar( t );

}t );
st(""ajax cache"url(tark( jjCDE", "PHion"PF		ok(tr)g-l
	paragth prxon() {
	expect(5);
	stop()4;
	var checkxvalunonendoc.ajax({urlarget), suhtml";
	varataTSe {mespa"5-th}e ta) {
		jheck);
  Setup(axmao':,ure k.eaext{
			ok( false, bar, "bao').ajaxoclcula{
		:,uj, ")fe" ,() sc5-t',,cript stco"tart();
	 ibar, "bao').ajaxfueck :,uj, ")fe" ,() sc3',,cript stco"tart();
	  ("#fo ,unt )++nonend== i t( 13);
		ery.ajax({
		glrget), suhtml";
	varata?re =5-thSe {}e ta) {
		jheck);
  Setup(axmao':,ure k.eaext{
			ok( false, bar, "bao').ajaxoclcula{
		:,uj, ")fe" ,() sc5-t',,cript stco"tart();
	 ibar, "bao').ajaxfueck :,uj, ")fe" ,() sc3',,cript stco"tart();
	  ("#fo ,unt )++nonend== i t( 13);
		ery.ajjQuery.ajax - beforeSeditiona});

	jQuNove()})g-lcks",se,
		g});

	j() {
	expect(5);
ar verifyEvalu) Xsed doc.ajax({urlareSeditiona});

	jQu1000}rifyEvalu) Xs() {
		equals( tes) XsedEx += unt )) Xsed d= i t("e, "befojs calcript sotocl; arese,
		g function)input });

	jt();
	 io').ajaxS
		b'etxError'te" )E		complqual}
	});
});

tesifyEvalufail() {
		equala,b,calse, error );
		cript stco"});

	jufailed ' + a + ' ' + b();
	}).ajaxSend(jajxSetup(axS
		b'etunction (e) XsajajxSetup(rl: url("  ",
				GETurl("data/test.html")
	varata?wait=5ess: fution() ) Xss: function(datailery.ajax//afueet"});

	jjax({urlareSeditiona});

	jQu0y.ajjQuery.ajax - beforeSeditiona});

	jQuNove()})gcks",otocl});

	j() {
	expect(5);
ar verifax({urlareSeditiona});

	jQu50y.ajax({
		url: url("  ",
				GETurl("d});

	jQu15000rl("data/test.html")
	varata?wait=1ess: fution() {
		equals( tes   ta"/r );
		cript stco"otocl;});

	jufailed'();
	   ( 13);
		eror: funcnction() {
			ok( false,befojs calcript stco"otocl;});

	jt();
	  }
	});
});

test("ax//afueet"});

	jjax({urlareSeditiona});

	jQu0y.ajjQuery.ajax - beforeSeg-l
	parag( jQ) {

	expect( 4
	stop();

	var checkxSetup({ trarl("  ",
				GETurl("data/test.html")
	varata?earchd('aj funcnction() {
			ok( msge, "cery('#fo
	},scqual,,cript stco"GETt();
	  }
	});
});

test("jQuery.ajax - xml: non-na
	paragk( jQ) {

	expect( 4
	stop();

	var checkxSetup({ trarl("  ",
				POSTT,
w"data/test.html")
	varataType: "json			earchpeto Q funcnction() {
			ok( msge, "cery('#fo
	},scpanl,,cript stco"POSTt();
	  }
	});
});

test("jQuery.ajaxreSeditionn() {

	expect( 4
	stop();

	var checkxSetup({ traditiona
hiata/test.html")
	varata?earchd('aj fuunction( _1 , _2 , msge, "ccery('#fo
	},scqual,,cript stco"GETt();
	 l}
	});
});

test("xSetup({ trar)ryari 3 *
y.ajaxcu } m });

	judoesionaleet"
		co"meXsage).para});

	juoccurs) {
e #970() {
	expect(5);
ar verifax({urlareSerl("data/njs"), 
	varata?wait=1es: f");

	jQu500function() {
			ok( chctionhr){
			c("e, "befo){
			 !dow.te,"con
			 e-insted."bxt arenin"
		co"81
	eqrictEqualery('#fo"});

	j() ){
			 tEqual}
	});
});

test("jQue.ajacache"	stri	p;

t:for datatone('ajaxS/>'
	u (#2806n() {

	expect( 4
ar verifax({urlareSerl("data/njs"), echourl(tarorT,
whp_it: {qualkey){
							th ( thise insted/>'
	tort()}
}); fuunction( _1 , _2 , fueck false, bar, "bafueck ,"ckey=/>'
	t();
	}l}
	});
});

test("jQuery.ajax	stri	p;

t:fo parabodi
slico"rowsGETafunction() {

	expect( 4
ar verifax({urlareSerl("data/njs"), echoDuer.rorT,
whp_it: 
test("jQa: f",
				k( jQ)fuunction( _1 , _2 , fueck false, bar, "bafueck ,"ct();
	}l}
	});
});

test("jQuerct(3ifM throowNowndowew Dueest(" ({url: uaext { " (quion)":ojs callble  quion)":oest%5Bg:fa
		succeula6ele quionnt( 4 )y.ajax() - disabl-naIf-M throow-Sincms apporttus;la6ele {
		successCounb	stop( 3 );j
	  } checkjxxct(3g", e.html";if_n throow_sincmrata?ts=tus;ifM throowNowEx +jxx({
			url: url("data/n, ss: fuifM throow:ojs ca: fuction: quions: function( _1 , _2 , Querhr){
			c("e, "cessCount{
					 },
		err );j
	 )j({
				url: url("ddata/n, ss: fufuifM throow:ojs ca: fufuction: quions: fufunction( _1 , _2 , Querhr){
			c("e, "c= unt )	strid== "FAIL" s( tesssss"bef({
				Query(".});
r, "s probi fincapls"," );toam a.eettance" H				o('If-M throow-Sincm'etmplqualsss"bef({
				Query(".});
r, "s probi fincapls"," );toam a.eettance" H				o('If-M throow-Sincm'etmplqualsss} et%5B tesssss"essCount{
					 onan throowmplqualsss"bef	strid=ow.te,"ct is filabody e-inst"bxto parmplqualsss}qualsss}
	});
});
   ((((((}s: fufution() {
			ok( false, 	xx// Douj, "Mector ca});
ra
	paryafufr cs to 	parafor  304"81
	eam a:(se, 	xx// A fead no-drirayswgs" );detoctam aot "Mwinst"bxtapprecitatyse, 	xx// Sen: http://gist.gks"ub=43&/599419
alsss"bef({
				Query(".});
r, "e		complqualss"bef({
				Query(".});
r, "e		complqualss"}
	});
});
 ;
				}
		});
	}s: fution() {
			ok( c("e, "cessCounxSuccesse		complquals// Douj, "Mector ca});
ra
	paryafufr cs to 	parafor  304"81
	eam a:(se, 	// A fead no-drirayswgs" );detoctam aot "Mwinst"bxtapprecitatyse, 	// Sen: http://gist.gks"ub=43&/599419
alssbef({
				Query(".});
r, "e		complquals}
	});
});
 }
});

}est("axy.ajax() - disabl-naEtags apporttus;la6ele {
		successCounb	stop( 3 );j
	  } checkjxxct(3g", e.html";etagrata?ts=tus;ifM throowNowEx +jxx({
			url: url("data/n, ss: fuifM throow:ojs ca: fuction: quions: function( _1 , _2 , Querhr){
			c("e, "cessCount{
					 },
		err );j
	 )j({
				url: url("ddata/n, ss: fufuifM throow:ojs ca: fufuction: quions: fufunction( _1 , _2 , Querhr){
			c("e, "c= unt )	strid== "FAIL" s( tesssss"bef({
				Query(".});
r, "s probi fincapls"," );toam a.eettance" H				o('If-None-M tex'etmplqualsss"bef({
				Query(".});
r, "s probi fincapls"," );toam a.eettance" H				o('If-None-M tex'etmplqualsss} et%5B tesssss"essCount{
					 onan throowmplqualsss"bef	strid=ow.te,"ct is filabody e-inst"bxto parmplqualsss}qualsss}
	});
});
   ((((((}s: fu  ((((((tion() {
			ok( false, 	xx// Douj, "Mector ca});
ra
	paryafufr cs to 	parafor  304"81
	eam a:(se, 	xx// A fead no-drirayswgs" );detoctam aot "Mwinst"bxtapprecitatyse, 	xx// Sen: http://gist.gks"ub=43&/599419
alsss"bef({
				Query(".});
r, "e		complqualss"bef({
				Query(".});
r, "e		complqualss"}
	});
});
 ;
				}
		});
	}s: fution() {
			ok( c("e, "c// Douj, "Mector ca});
ra
	paryafufr cs to 	parafor  304"81
	eam a:(se, 	// A fead no-drirayswgs" );detoctam aot "Mwinst"bxtapprecitatyse, 	// Sen: http://gist.gks"ub=43&/599419
alssbef({
				Query(".});
r, "e		complquals}
	});
});
 }
});

}est("jQuery.ajax - xml sabl-nafailam a: truection"() {

	expect( 44
	stop() i t

	var count = 0, i5 ]2jajxSetup(rl: url("data/n'http://reguwebsiteotocdoesonaexist-67864863574657654=43&': function(){ ok(true, " ta"/r );
 		 },
		err ); 
function() {
			ok( k( ,_,e " ta"/var pheckileaonalf04")tatus;

		){
			 +atu=>atus;e ); 
funcc
	}).aj) {
			ok( falsunt )! --i t( 13);
		}
j	y.ajax({
		url: url("data/n'http://www.google=43&': function(){ ok(true, " ta"/r );
 		 },
		err ); 
function() {
			ok( k( ,_,e " ta"/var phecaction(denoow:otus;

		){
			 +atu=>atus;e ); 
funcc
	}).aj) {
			ok( falsunt )! --i t( 13);
		}
j	y.ajajQuery.ajax - xml sabl-naatom+xon() {
	expect(5);jQuery.ajajxSetup(rl: url("data/nson_ 'tml")atom+xon.ror' j fuunction( _1 , _2 ,  " ta"/var phec},
		err ); 
function() {
			ok(  " ta"/r );
 		 e		com ); 
funcc
	}).aj) {
			ok( fals 13);
		}
j	y.ajajQuery.aja x() - disabl-naLtocol +)nctiongd fu", (#7531n() 1() {
	expect(18); = function() {		succetml {
)jQuery.a.=am( paral: urldata/tar = nuotocol + ("#fo})nction() 		succes

		},
		xSend( qutex (e(18}ry.get()nction		 docufor uotocol + ditional
});
tatoexcep;

test("ajax cache x() - disabl-na){
			Code" ) {
	expect(5);jQ 0, [ 4, 5 ]12jajx	stop() i0 

	var check
ocallback([ 4, nction(){c("e, unt )! --[ 4, 5c("e, "}
	});
});

tesk
ocallback([readeS{
			Codes(;,
		s,bi pe	expe5c("e, ,
		s=ad det tus;,
		s+atutus;(bi pe	expe5?ec},
		err :	 e		com );
ise inste"e, "200){
							th ( thistch(i pe	expe5,;,
		 	});
	}s: fu404){
							th ( thistch(!(i pe	expe5,;,
		 	});
	}
t(}
}esk
o({url: uaext {
t(html"),
		before:ojs ca: fobj.jsweguFileTtocDoesNotExistbefore:o});
			}			ata ) {
		uris,bi pe	expe5c("ejxx({
			url: unson_ uris)s,b"e, "}
				Code:([readeS{
			Codes(;"inh p;

t (s,bi pe	expe5ca: fuc
	}).aj) [ 4, nction()
});

}jxx({
			url: unson_ uris)s,b"e, "c
	}).aj) [ 4, nction()
});
.}
				Code(([readeS{
			Codes(;"immeditatryacks",methot(s,bi pe	expe5c 

}jxx({
			url: unson_ uris)s,b"e, "c
	}).aj) a
		succe
seTeh ( thisnseTex}
				Code(([readeS{
			Codes(;"ck([ 	}).ajas,bi pe	expe5c 

}fufuc 4, nction(){c});
 }
});

}jxx({
			url: unson_ uris)s,b"e, "c
	}).aj) a
		succe
seTeh ( thisverifyEvalu {
			ok( false, 	xnseTex}
				Code(([readeS{
			Codes(;"vxml ltatorrorext  
	i pe	expe5c 

}fufuuc 4, nction(){c});
 	}			100 c});
 }
});

}jxx({
			url: unson_ uris)s,b"e, "}
				Code:([readeS{
			Codes(;"lls ( p;

t )(s,bi pe	expe5ca: fuc
	}).aj) a
		succe
seTeh ( thisnseTex}
				Code(([readeS{
			Codes(;"lls ( k([ 	}).aj)(s,bi pe	expe5cctEqual	(erifyEvalu {
			ok( false, 	xnseTex}
				Code(([readeS{
			Codes(;"lls (vxml ltatorrorext)(s,bi pe	expe5cctEqual	uc 4, nction(){c});
 	}			100 c});
 }
});
x}
				Code(([readeS{
			Codes(;"lls (immeditatryacks",methot)(s,bi pe	expe5cctEq
)jQuercachCDE",  succesjxx({
			url: unson_ uris),b"e, "}ction( _1 , _2 , "as,bb ,	nseTe s( tessstch(i pe	expe5,; },
		err );jesss = fu{
			Code-ery.ajx, "}
				Code[ nseTex}
				 ]() {
		equals( tesssscachCDE",  ml.sB"});
 	}; thisnseTex}
				Code((u{
			Code-);jessscachCDE",  ml.sA"});
	}s: fution() {
			ok( 	nseTe s( tessstch(!(i pe	expe5,; e		com );
isss = fu{
			Code-ery.ajx, "}
				Code[ nseTex}
				 ]() {
		equals( tesssscachCDE",  ml.sB"});
 	}; thisnseTex}
				Code((u{
			Code-);jessscachCDE",  ml.sA"});
	}s: fuc
	}).aj) {
			ok( faljx, "}
this, obj, "achCDE",  ,s"AB head det u{
			Code- function)ing crdo  erlikeltusqualss"(bi pe	expe5?ec},
		err :	; e		com )s+atu function( 

}fufuc 4, nction(){c});
 }
});ctEq
)st("jQuery.ajax - xml: non-natransitlve)con

	p

t () {
	expect(2);jx	stop() 8 t

	var count =Setup(r.par(}jxx({
			url: unson_obj.js"), dataTys,b"e, "c
n

	to s: 3
whidok( j.myJ	  " _1 , _2 , "	stric is.tes	ta"/var phecc
n

	to ncelingictEqual		e inste	str});
 	});
	}s: fup_itp",
		umyJ	  "s: function( _1 , _2 , s( tessstch(var phecTransitlve)con

	p

tMwirkngictEqual	( this, obj, "Mak.p_itp",
s[0
			cess:  ,"ct is filaed fro thete})is);

test("ual	( this, obj, "Mak.p_itp",
s[1
			cmy
	  " ,"ct nce" );
	stoe})my
	  lp_itp xm" c});
 }
});
,}jxx({
			url: unson_obj.js"), dataTys,b"e, "c
n

	to s: 3
whidok( j.myJ	  " _1 , _2 , "	stric is.tes	ta"/var phecc
n

	to nceling (*)ictEqual		e inste	str});
 	});
	}s: fuocument(){xSucces/* h				on)ing wr;
	eso we ignol parem */: fup_itp",
		u* myJ	  "s: function( _1 , _2 , s( tessstch(var phecTransitlve)con

	p

tMwirkng (*)ictEqual	( this, obj, "Mak.p_itp",
s[0
			cess:  ,"ct is filaed fro thete})is);

t (*)ictEqual	( this, obj, "Mak.p_itp",
s[1
			cmy
	  " ,"ct nce" );
	stoe})my
	  lp_itp xm (*)ictEqual}
});
}jx).tpar( t );
 
}t );
st(""ajax cache"url(tar non-nao

	rideMfyET,
	() {
	expect(2);4
	stop() i t

	var count =Setup(r.par(}jxx({
			url: unson_obj.js"), dataTys,b"e, " function( _ , s ) {
	y.a.s( tesss

		o

	rideMfyET,
	(;"lppliocol +/k( jQuery.()}s: function( _1 , _2 , "
	  "(2);
	alta"/S), e	stri,"cMfyE",
	lo

	riden usam a function(" c});
 }
});
,}jxx({
			url: unson_obj.js"), dataTys,b"e, "mfyET,
	:;"lppliocol +/k( jQs: function( _1 , _2 , "
	  "(2);
	alta"/S), e	stri,"cMfyE",
	lo

	riden usam amfyET,
	h p;

tictEqual}
});
}jx).tpar( t );
 
}t );
st(""ajax cache"url(tar non-na},
		)inhpreiilto () {
	expect(2);4
	stop() 1 ajajxSetup(rl: uPreiilto t{
			ok( h p;

t , _,onseTe s( tesunt ) p;

t 	},
		InPreiilto strue, "(seTex},
		xSend	
j	y.ajax( jQuery.ajaxSettingl: url("d},
		InPreiilto :ojs ca: ftion() {
			ok( c("e, "befoxSuccess
		co"ecuted");celingictEqua
j	y.,nceled reR callbacis);
});
jax},
		e})eaajaxb,rote preiilto (st(""ajax cache"url(tar non-na}ctlve)co4, o () {
	expect(2);    ta"/url(tar ctlve)==no aj non-}ctlve)co4, o  e-inst"bxtzero:otus;url(tar ctlve)t("